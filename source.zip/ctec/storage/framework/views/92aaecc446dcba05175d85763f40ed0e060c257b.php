<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('content'); ?>
    <div class="block-content">

        <!-- Page Header -->
        <div class="page-header">
            <hr>
            <h5 class="page-title"><?php echo e($post->title); ?></h5>
            <span class="page-date"><i class="fa fa-calendar"></i> <?php echo e($post->created_at); ?></span>
            <hr>
        </div>
        <!-- End Page Header -->

        <!-- post content -->
        <div class="post-content">
            <?php echo $post->content; ?>

        </div>
        <hr>
        <!-- end post content -->

        <div class="post-related">
            <span>Các tin liên quan:</span>
            <div class="related-link title">
                <ul>
                <?php $__currentLoopData = $posts_rl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="wow slideInUp">
                        <a href="baiviet/<?php echo e($post_rl->slug); ?>.html"><?php echo e($post_rl->title); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/pages/post.blade.php ENDPATH**/ ?>
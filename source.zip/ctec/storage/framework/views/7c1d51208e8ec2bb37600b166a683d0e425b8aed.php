<header>
    <!-- Container -->
    <div class="container">

        <!-- Top Banner -->
        <div id="top-baner" class="d-none d-sm-block">
            <img class="img-fluid" src="upload/website/banner/<?php echo e($site_banner->value); ?>" alt="">
        </div>
        <!-- End Top Banner -->

        <!-- Main Menu -->
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Main Menu -->

        <!-- Top Slides -->
        <?php echo $__env->make('layouts.slides', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Top Slides -->

    </div>
    <!-- End Container -->
</header><?php /**PATH C:\xampp\htdocs\ctec\resources\views/layouts/header.blade.php ENDPATH**/ ?>
<div id="slides" class="carousel slide" data-ride="carousel">

    <!-- Indicators -->
    <ul class="carousel-indicators">
        <?php
            $i = 0;
        ?>
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-target="#slides" data-slide-to="<?php echo $i; ?>" class="<?php echo e($i == 0 ? 'active' : ''); ?>"></li>
        <?php
            $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- The slideshow -->
    <div class="carousel-inner">
        <?php
            $i = 0;
        ?>
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($i == 0 ? 'active' : ''); ?>">
            <a href="<?php echo e($slide->url); ?>" target="_blank">
                <img class="d-block" src="upload/website/slides/<?php echo e($slide->image); ?>" alt="">
            </a>
        </div>
        <?php
            $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Left and right controls -->
    <a class="carousel-control-prev" href="#slides" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#slides" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>

</div><?php /**PATH C:\xampp\htdocs\ctec\resources\views/layouts/slides.blade.php ENDPATH**/ ?>
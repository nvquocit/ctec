<?php $__env->startSection('title', 'Danh sách người dùng'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Danh Sách Người Dùng</h1>
                </div><!-- /.col -->
                <div class="col-sm-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="admin"><i class="fa fa-home"></i> Trang Chủ</a>
                            </li>
                            <li class="breadcrumb-item"><a href="admin/nguoidung/danhsach">Người Dùng</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Danh Sách</li>
                        </ol>
                    </nav>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title float-left">Danh Sách Người Dùng</h3>
                            <?php if(Auth::user()->rule == 1): ?>
                                <a class="btn btn-primary float-right" href="admin/nguoidung/them"><i class="fa fa-plus-circle"></i> Thêm</a>
                            <?php endif; ?>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="user-list" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Avatar</th>
                                        <th>Tên Người Dùng</th>
                                        <th>Email</th>
                                        <th>Quyền</th>
                                        <?php if(Auth::user()->rule == 1): ?>
                                        <th>Sửa</th>
                                        <th>Xóa</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $stt = 1;
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($stt); ?></td>
                                        <td>
                                            <img class="img-circle img-fluid" src="upload/website/avatar/<?php echo e($user->avatar); ?>" alt=""
                                                width="75px" height="75px">
                                        </td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <?php if($user->rule == 0): ?>
                                                <span class="badge btn btn-outline-dark">Thành Viên</span>
                                            <?php else: ?>
                                                <span class="badge btn btn-outline-warning">Admin</span>
                                            <?php endif; ?>
                                        </td>
                                        <?php if(Auth::user()->rule ==1): ?>
                                        <td><a href="admin/nguoidung/sua/<?php echo e($user->id); ?>"><i class="fa fa-edit btn btn-success"></i></a></td>
                                        <td><a href="admin/nguoidung/xoa/<?php echo e($user->id); ?>" onclick="return confirm('Người dùng có <?php echo e(count($user->post)); ?> bài viết!\nXác nhận xóa?');"><i class="fa fa-trash btn btn-danger"></i></a></td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php
                                        $stt++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </div>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
            $('#user-list').DataTable({
                "language": {
                    "sProcessing": "Đang xử lý...",
                    "sLengthMenu": "Xem _MENU_ mục",
                    "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
                    "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
                    "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
                    "sInfoFiltered": "(được lọc từ _MAX_ mục)",
                    "sInfoPostFix": "",
                    "sSearch": "Tìm:",
                    "sUrl": "",
                    "oPaginate": {
                        "sFirst": "Đầu",
                        "sPrevious": "Trước",
                        "sNext": "Tiếp",
                        "sLast": "Cuối"
                    }
                }
            });
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/admin/users/list.blade.php ENDPATH**/ ?>
<nav class="navbar navbar-expand-lg navbar-light bg-primary rounded">
    <a class="navbar-brand" href="/"><i class="fa fa-home text-white"></i></a>
    <button class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="fa fa-bars text-white"></span>
    </button>
    <div id="navbarSupportedContent" class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($menu->children) == 0): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e($menu->url); ?>"><?php echo e($menu->label); ?></a>
            </li>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="<?php echo e($menu->url); ?>" id="navbarDropdown" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <?php echo e($menu->label); ?>

                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <?php $__currentLoopData = $menu->children->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($sub->children) == 0): ?>
                    <li><a class="dropdown-item" href="<?php echo e($sub->url); ?>"><?php echo e($sub->label); ?></a></li>
                <?php else: ?>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="<?php echo e($sub->url); ?>"><?php echo e($sub->label); ?></a>
                        <ul class="dropdown-menu">
                        <?php $__currentLoopData = $sub->children->sortBy('position'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e($sub2->url); ?>"><?php echo e($sub2->label); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\ctec\resources\views/layouts/menu.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Trang Chủ'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Block content -->
    <div class="block-content">

        <!-- header title -->
        <div class="header-title">
            <span class="h-title">
                <i class="fa fa-newspaper-o"></i>
                <a href="loaitin/tin-tuc-su-kien"> Tin Tức Sự Kiện</a>
            </span>
            <span class="h-title read-more d-none d-sm-block">
                <a href="loaitin/tin-tuc-su-kien"> Xem Thêm <i class="fa fa-chevron-circle-right"></i></a>
            </span>
        </div>
        <!-- End Header title -->

        <!-- Block listing -->
        <div class="row block-listing bdb">

            <!-- Post large -->
            <?php $__currentLoopData = $cat_ttsk->post->where('status', 1)->sortByDesc('id')->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $post_des = strip_tags(str_limit($post_lg->content, 250,'...'));
            ?>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6 post-lg bdr">
                <a href="baiviet/<?php echo e($post_lg->slug); ?>.html">
                    <img class="img-fluid wow zoomIn" src="upload/images/baiviet/<?php echo e($post_lg->image); ?>" alt="">
                </a>
                <span class="title">
                    <a href="baiviet/<?php echo e($post_lg->slug); ?>.html"><?php echo e($post_lg->title); ?></a>
                </span>
                <p class="p-des">
                    <?php echo $post_des; ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Post Large -->

            <!-- Post vertical -->
            <div class="col-12 col-md-12 col-lg-6 post-vertical">
                <?php $__currentLoopData = $cat_ttsk->post->where('status', 1)->sortByDesc('id')->slice(1)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Listing post -->
                <div class="row sm-listing wow slideInUp">
                    <div class="col-5 col-md-4 col-lg-4 sm-thumbnail">
                        <img class="img-fluid" src="upload/images/baiviet/<?php echo e($post_vt->image); ?>" alt="">
                    </div>
                    <div class="col-7 col-md-8 col-lg-8 sm-title">
                        <span class="title">
                            <a href="baiviet/<?php echo e($post_vt->slug); ?>.html"><?php echo e($post_vt->title); ?></a>
                        </span>
                    </div>
                </div>
                <hr>
                <!-- End Listing Post -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End Post Vertical -->
        </div>
        <!-- End Block Listing -->

        <!-- header title -->
        <div class="header-title">
            <span class="h-title">
                <i class="fa fa-bullhorn"></i>
                <a href="loaitin/thong-bao"> Thông Báo</a>
            </span>
            <span class="h-title read-more d-none d-sm-block">
                <i class="fa fa-chevron-circle-right"></i>
                <a href="loaitin/thong-bao"> Xem Thêm </i></a>
            </span>
        </div>
        <!-- End Header title -->

        <!-- Block listing -->
        <div id="post-slide" class="carousel slide" data-ride="carousel">
        
            <!-- The slideshow -->
            <div class="carousel-inner">
                <div class="carousel-item active wow slideInRight">
                    <div class="row block-listing">
                    <!-- Post Inline -->
                    <div class="col-md-12 col-lg-12">
                        <div class="row post-inline">
                            <?php $__currentLoopData = $cat_tb->post->where('status', 1)->sortByDesc('id')->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-6 col-lg-3">
                                <img class="img-fluid"
                                    src="upload/images/baiviet/<?php echo e($post_slide->image); ?>" alt="">
                                <span class="title">
                                    <a href="#"><?php echo e($post_slide->title); ?></a>
                                </span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- End Post Inline -->
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row block-listing">
                    <!-- Post Inline -->
                    <div class="col-md-12 col-lg-12">
                        <div class="row post-inline">
                            <?php $__currentLoopData = $cat_tb->post->where('status', 1)->sortByDesc('id')->slice(4)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-md-6 col-lg-3">
                                <img class="img-fluid"
                                    src="upload/images/baiviet/<?php echo e($post_slide->image); ?>" alt="">
                                <span class="title">
                                    <a href="baiviet/<?php echo e($post_slide->slug); ?>.html"><?php echo e($post_slide->title); ?></a>
                                </span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- End Post Inline -->
                    </div>
                </div>
            </div>
        
            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#post-slide" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#post-slide" data-slide="next">
                <span class="carousel-control-next-icon"></span>
            </a>
        
        </div>
        <hr>
        <!-- End Block Listing -->

        <!-- header title -->
        <div class="header-title">
            <span class="h-title">
                <i class="fa fa-graduation-cap"></i>
                <a href="loaitin/tin-tuyen-sinh"> Tin Tuyển Sinh</a>
            </span>
            <span class="h-title read-more d-none d-sm-block">
                <a href="loaitin/tin-tuyen-sinh"> Xem Thêm <i class="fa fa-chevron-circle-right"></i></a>
            </span>
        </div>
        <!-- End Header title -->

        <!-- Block listing -->
        <div class="row block-listing bdb">
            <!-- Post large -->
            <?php $__currentLoopData = $cat_tts->post->where('status', 1)->sortByDesc('id')->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $post_des = strip_tags(str_limit($post_lg->content, 250,'...'));
            ?>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6 post-lg bdr">
                <a href="baiviet/<?php echo e($post_lg->slug); ?>.html">
                    <img class="img-fluid wow zoomIn" src="upload/images/baiviet/<?php echo e($post_lg->image); ?>" alt="">
                </a>
                <span class="title">
                    <a href="baiviet/<?php echo e($post_lg->slug); ?>.html"><?php echo e($post_lg->title); ?></a>
                </span>
                <p class="p-des">
                    <?php echo $post_des; ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Post Large -->

            <!-- Post vertical -->
            <div class="col-12 col-md-12 col-lg-6 post-vertical">
                <!-- Listing post -->
                <?php $__currentLoopData = $cat_tts->post->where('status', 1)->sortByDesc('id')->slice(1)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row sm-listing wow slideInUp">
                    <div class="col-5 col-md-4 col-lg-4 sm-thumbnail">
                        <img class="img-fluid" src="upload/images/baiviet/<?php echo e($post_vt->image); ?>" alt="">
                    </div>
                    <div class="col-7 col-md-8 col-lg-8 sm-title">
                        <span class="title">
                            <a href="baiviet/<?php echo e($post_vt->slug); ?>.html"><?php echo e($post_vt->title); ?></a>
                        </span>
                    </div>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End Listing Post -->
            </div>
            <!-- End Post Vertical -->
        </div>
        <!-- End Block Listing -->

    </div>
    <!-- End Block content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/pages/index.blade.php ENDPATH**/ ?>
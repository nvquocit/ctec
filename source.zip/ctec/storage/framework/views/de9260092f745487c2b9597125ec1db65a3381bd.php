<?php $__env->startSection('title', 'Danh Sách Bài Viết'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Danh Sách Bài Viết</h1>
                </div><!-- /.col -->
                <div class="col-sm-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="admin"><i class="fa fa-home"></i> Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="admin/baiviet/danhsach">Bài Viết</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Danh Sách</li>
                        </ol>
                    </nav>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title float-left">Danh Sách Bài Viết</h3>
                            <a class="btn btn-primary float-right" href="admin/baiviet/them"><i class="fa fa-plus-circle"></i> Thêm</a>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="post-list" class="table table-bordered table-responsive text-center">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Ảnh</th>
                                        <th>Tiêu đề bài viết</th>
                                        <th>Tên tác giả</th>
                                        <th>Loại tin</th>
                                        <th>Nổi bật</th>
                                        <th>Trạng thái</th>
                                        <th>Sửa</th>
                                        <th>Xóa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $stt = 1;
                                    ?>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($stt); ?></td>
                                            <td>
                                                <img src="upload/images/baiviet/<?php echo e($post->image); ?>" class="img-fluid" style="width: 175px; height: 100px;" alt="">
                                            </td>
                                            <td><a href="baiviet/<?php echo e($post->slug); ?>.html" target="_blank"><?php echo e($post->title); ?></a></td>
                                            <td><?php echo e($post->user->name); ?></td>
                                            <td><?php echo e($post->category->name); ?></td>
                                            <td>
                                                <?php if($post->is_hot == 0): ?>
                                                    <span class="badge btn btn-outline-info">Không</span>
                                                <?php else: ?>
                                                    <span class="badge btn btn-outline-warning">Nổi Bật</span>
                                                <?php endif; ?>                        
                                            </td>
                                            <td>
                                                <?php if($post->status == 0): ?>
                                                    <span class="badge btn btn-secondary">Lưu Nháp</span>
                                                <?php else: ?>
                                                    <span class="badge btn btn-primary">Xuất Bản</span>
                                                <?php endif; ?>
                                            </td>
                                            <?php if(Auth::user()->rule == 1): ?>
                                            <td><a href="admin/baiviet/sua/<?php echo e($post->id); ?>"><i class="fa fa-edit btn btn-success"></i></a></td>
                                            <td><a href="admin/baiviet/xoa/<?php echo e($post->id); ?>" onclick="return confirm('Xác nhận xóa bài viết này?');"><i class="fa fa-trash btn btn-danger"></i></a></td>
                                            <?php else: ?>
                                                <?php if($post->user->id == Auth::user()->id): ?>
                                                    <td><a href="admin/baiviet/sua/<?php echo e($post->id); ?>"><i class="fa fa-edit btn btn-success"></i></a></td>
                                                    <td><a href="admin/baiviet/xoa/<?php echo e($post->id); ?>"><i class="fa fa-trash btn btn-danger" onclick="return confirm('Xác nhận xóa bài viết này?');"></i></a></td>
                                                <?php else: ?>
                                                    <td><i class="fa fa-edit btn btn-default text-muted"></i></td>
                                                    <td><i class="fa fa-trash btn btn-default text-muted"></i></td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php
                                        $stt++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </div>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
      $('#post-list').DataTable({
        "language": {
          "sProcessing": "Đang xử lý...",
          "sLengthMenu": "Xem _MENU_ mục",
          "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
          "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
          "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
          "sInfoFiltered": "(được lọc từ _MAX_ mục)",
          "sInfoPostFix": "",
          "sSearch": "Tìm:",
          "sUrl": "",
          "oPaginate": {
            "sFirst": "Đầu",
            "sPrevious": "Trước",
            "sNext": "Tiếp",
            "sLast": "Cuối"
          }
        }
      });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/admin/posts/list.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="<?php echo e($site_description->value); ?>">
    <link rel="shortcut icon" href="upload/website/icon/<?php echo e($site_icon->value); ?>" type="image/x-icon">
    <base href="<?php echo e(asset('')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($site_title->value); ?></title>

    <!-- Bootstrap Files -->
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
    <!-- Font-awesome Files -->
    <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
    <!-- Animate.css Files -->
    <link rel="stylesheet" href="bower_components/animate.css/animate.css">
    <!-- Styles -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Header -->

    <!-- Main -->
    <main>
        <!-- Container -->
        <div class="container">
            <!-- Row Content -->
            <div class="row main-content">
                <!-- Left -->
                <div class="col-12 col-md-8 col-lg-9 bdr">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                <!-- End Left -->

                <!-- Right -->
                <div class="col-12 col-md-4 col-lg-3 sidebar">

                    <!-- Block Content -->
                    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- End Block Content -->
                    
                </div>
                <!-- End Right -->
            </div>
            <!-- End Row Content -->
        </div>
        <!-- End Container -->
    </main>
    <!-- End Main -->

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Footer -->

    <!-- Jquery Files -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Popper.js Files -->
    <script src="bower_components/popper.js/dist/popper.min.js"></script>
    <!-- Bootstrap Files -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Wow.js Files -->
    <script src="bower_components/wow/wow.min.js"></script>
    <!-- Main Script -->
    <script src="js/main.js"></script>
    <script>
        new WOW().init();
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\ctec\resources\views/layouts/master.blade.php ENDPATH**/ ?>
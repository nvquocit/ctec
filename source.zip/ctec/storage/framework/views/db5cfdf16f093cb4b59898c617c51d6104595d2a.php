<?php $__env->startSection('title', $page->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="block-content">

        <!-- Page Header -->
        <div class="page-header">
            <hr>
            <h5 class="page-title"><?php echo e($page->name); ?></h5>
            <span class="page-date"><i class="fa fa-calendar"></i> <?php echo e($page->created_at); ?></span>
            <hr>
        </div>
        <!-- End Page Header -->

        <!-- post content -->
        <div class="post-content">
            <?php echo $page->content; ?>

        </div>
        <hr>
        <!-- end post content -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/pages/page.blade.php ENDPATH**/ ?>
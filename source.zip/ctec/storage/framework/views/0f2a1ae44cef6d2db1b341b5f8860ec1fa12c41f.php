<?php $__env->startSection('title', 'Danh Sách Loại Tin'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Loại Tin</h1>
                </div><!-- /.col -->
                <div class="col-sm-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="admin"><i class="fa fa-home"></i> Trang Chủ</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Loại Tin</li>
                        </ol>
                    </nav>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">

                <?php if(Auth::user()->rule == 1): ?>
                    <div class="col-sm-4">
                    <form action="admin/loaitin" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title float-left">Thêm loại tin</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="">Tên loại tin</label>
                                    <div class="text-danger mb-2">
                                        <?php echo e($errors->first('name')); ?>

                                    </div>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required placeholder="Nhập tên loại tin...">
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <!-- /.card-footer -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-info">Lưu lại</button>
                                <button type="reset" class="btn btn-default float-right">Hủy bỏ</button>
                            </div>
                            <!-- /.card-footer -->
                        </div>
                        <!-- /.card -->
                    </form>
                </div>
                <!-- /.col -->
                <?php endif; ?>

                <?php if(Auth::user()->rule == 1): ?>
                    <div class="col-sm-8">
                <?php else: ?>
                    <div class="col-sm-12">
                <?php endif; ?>
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title float-left">Danh Sách Loại Tin</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="cat-list" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên loại tin</th>
                                        <th>Slug</th>
                                        <th>Tổng số bài viết</th>
                                        <?php if(Auth::user()->rule == 1): ?>
                                        <th>Sửa</th>
                                        <th>Xóa</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $stt = 1;
                                    ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($stt); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->slug); ?></td>
                                        <td><span class="badge bg-primary"><i class="mr-2 ml-2"><?php echo e(count($category->post)); ?></i></span></td>
                                        <?php if(Auth::user()->rule == 1): ?>
                                        <td><a href="admin/loaitin/sua/<?php echo e($category->id); ?>"><i class="fa fa-edit btn btn-success"></i></a></td>
                                        <td><a href="admin/loaitin/xoa/<?php echo e($category->id); ?>" onclick="return confirm('Loại tin có <?php echo e(count($category->post)); ?> bài viết!\nXác nhận xóa?');"><i class="fa fa-trash btn btn-danger"></i></a></td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php
                                        $stt++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </div>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
      $('#cat-list').DataTable({
        "language": {
          "sProcessing": "Đang xử lý...",
          "sLengthMenu": "Xem _MENU_ mục",
          "sZeroRecords": "Không tìm thấy dòng nào phù hợp",
          "sInfo": "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
          "sInfoEmpty": "Đang xem 0 đến 0 trong tổng số 0 mục",
          "sInfoFiltered": "(được lọc từ _MAX_ mục)",
          "sInfoPostFix": "",
          "sSearch": "Tìm:",
          "sUrl": "",
          "oPaginate": {
            "sFirst": "Đầu",
            "sPrevious": "Trước",
            "sNext": "Tiếp",
            "sLast": "Cuối"
          }
        }
      });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/admin/categories/list.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="block-content">

        <!-- Page Header -->
        <div class="page-header">
            <hr>
            <h5 class="page-title"><?php echo e($category->name); ?></h5>
            <hr>
        </div>
        <!-- End Page Header -->

        <!-- page content -->
        <div class="page-content">
        
            <!-- post list -->
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $post_des = strip_tags(str_limit($post->content, 250, '...'));
            ?>
            <div class="list-block">
                <div class="row wow slideInUp">
                    <div class="col-sm-3">
                        <a href="baiviet/<?php echo e($post->slug); ?>.html">
                            <img class="img-fluid"
                                src="upload/images/baiviet/<?php echo e($post->image); ?>"
                                alt="">
                        </a>
                    </div>
                    <div class="col-sm-9">
                        <h6 class="title">
                            <a href="baiviet/<?php echo e($post->slug); ?>.html">
                                <?php echo e($post->title); ?>

                            </a>
                        </h6>
                        <span>
                            <?php echo $post_des; ?>

                        </span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- end post list -->
        
        </div>
        <!-- end page content -->

        <!-- pagination -->
        <div class="page-pagination text-center">
            <?php echo e($posts->links()); ?>

        </div>
        <hr>
        <!-- end pagination -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ctec\resources\views/pages/category.blade.php ENDPATH**/ ?>
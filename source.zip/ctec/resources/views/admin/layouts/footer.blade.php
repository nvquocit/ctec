<!-- Main Footer -->
<footer class="main-footer">
    <div class="text-center">
        <strong>Thiết kế bởi sinh viên CTEC</strong>
    </div>
</footer>
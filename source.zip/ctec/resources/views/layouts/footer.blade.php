<footer>
    <div class="container">
        <div class="footer-content">
            <span>
                Bản quyền thuộc Trường Cao đẳng Kinh tế - Kỹ thuật Cần Thơ<br>
                Địa chỉ: Số 9, đường Cách mạng Tháng tám, Phường An Hòa, Quận Ninh Kiều, TP. Cần Thơ<br>
                Điện thoai: (84-0292) 3826072 ; Fax: (84-0292) 3821326 ; Email: ktktct@ctec.edu.vn
            </span>
        </div>
    </div>
</footer>